package com.findmyclass.findclass;

import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Portada extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portada);

    }

    public void Empezar (View vista)
    {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
