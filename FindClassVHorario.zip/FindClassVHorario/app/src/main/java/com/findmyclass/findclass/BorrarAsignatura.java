package com.findmyclass.findclass;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class BorrarAsignatura extends Activity {

    private ListView lista;
    private TextView texto;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.borrar_asignatura);
        lista = (ListView)findViewById(R.id.LstOpciones);
        texto = (TextView)findViewById(R.id.text_selecciona);

        final String[] asignaturas = fileList();

        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, asignaturas);


        lista.setAdapter(adaptador);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> a, View v, int position, long id){
                String opcionSele = asignaturas[position];
                deleteFile(opcionSele);
                finish();
                }
            });
    }

}
