package com.findmyclass.findclass;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class HorarioClase extends Activity
{

    Spinner dias_semana1, dias_semana2, dias_semana3;
    //String[] dias = {"Nada", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes"};

    private EditText nombreAsig = null;
    private EditText horaInicio1 = null, horaFin1 = null;
    private EditText horaInicio2 = null, horaFin2 = null;
    private EditText horaInicio3 = null, horaFin3 = null;
    private TextView  prueba, prueba2, prueba3;

    int indice_dias = 0;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.horario);

        nombreAsig = (EditText)findViewById(R.id.nombre_asignatura);
        horaInicio1 = (EditText)findViewById(R.id.hora_inicio);
        horaFin1 = (EditText)findViewById(R.id.hora_fin);
        horaInicio2 = (EditText)findViewById(R.id.hora_inicio2);
        horaFin2 = (EditText) findViewById(R.id.hora_fin2);
        horaInicio3 = (EditText) findViewById(R.id.hora_inicio3);
        horaFin3 = (EditText) findViewById(R.id.hora_fin3);

        prueba = (TextView) findViewById(R.id.prueba);
        prueba2  = (TextView) findViewById(R.id.prueba2);
        prueba3 = (TextView) findViewById(R.id.prueba3);

        dias_semana1 = (Spinner)findViewById(R.id.dia_semana);
        //ArrayAdapter<String> adaptadorDias = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, dias);

        ArrayAdapter<CharSequence> adaptadorDias = ArrayAdapter.createFromResource(this, R.array.dias, android.R.layout.simple_spinner_item);
        adaptadorDias.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        
        dias_semana1.setAdapter(adaptadorDias);

        dias_semana2 = (Spinner)findViewById(R.id.dia_semana2);
        dias_semana2.setAdapter(adaptadorDias);

        dias_semana3 = (Spinner)findViewById(R.id.dia_semana3);

        dias_semana3.setAdapter(adaptadorDias);

    }

    public void añadir(View view){
        String nombre = nombreAsig.getText().toString();
        String dia1, dia2, dia3;
        String Inicio1 = null, Fin1 = null;
        String Inicio2 = null, Fin2 = null;
        String Inicio3 = null, Fin3 = null;


        String selec1 = dias_semana1.getSelectedItem().toString();
        if(selec1.equals("Nada")){
            dia1 = "Nada";
        }
        else{
            dia1 = selec1;
            Inicio1 = horaInicio1.getText().toString();
            Fin1 = horaFin1.getText().toString();
        }


        String selec2 = dias_semana2.getSelectedItem().toString();
        if(selec2.equals("Nada")){
            dia2 = "Nada";
        }
        else{
            dia2 = selec2;
            Inicio2 = horaInicio2.getText().toString();
            Fin2 = horaFin2.getText().toString();
        }


        String selec3 = dias_semana3.getSelectedItem().toString();
        if(selec3.equals("Nada")){
            dia3 = "Nada";
        }
        else{
            dia3 = selec3;
            Inicio3 = horaInicio3.getText().toString();
            Fin3 = horaFin3.getText().toString();
        }
        prueba.setText(dia1);


        try
        {
            OutputStreamWriter fout= new OutputStreamWriter(openFileOutput(nombre, Context.MODE_PRIVATE));

            fout.write(nombre);
            fout.write("\n");
            fout.write(dia1);
            fout.write("\n");
            if(dia1 != "Nada"){
                fout.write(Inicio1);
                fout.write("\n");
                fout.write(Fin1);
                fout.write("\n");
            }
            fout.write(dia2);
            fout.write("\n");
            if(dia2 != "Nada"){
                fout.write(Inicio2);
                fout.write("\n");
                fout.write(Fin2);
                fout.write("\n");
            }
            fout.write(dia3);
            fout.write("\n");
            if(dia3 != "Nada"){
                fout.write(Inicio3);
                fout.write("\n");
                fout.write(Fin3);
                fout.write("\n");
            }
            Log.i("Ficheros", "Fichero creado!");

            fout.close();
        }
        catch (Exception ex)
        {
            Log.e("Ficheros", "Error al escribir fichero a memoria interna");
        }
        this.onCreate(null);

    }

    public void mostrar(View view){

     /*   String[] asignaturas = fileList();

        ArrayList<String> lunes = new ArrayList<String>();
        ArrayList<String> martes = new ArrayList<String>();
        ArrayList<String> miercoles = new ArrayList<String>();
        ArrayList<String> jueves = new ArrayList<String>();
        ArrayList<String> viernes = new ArrayList<String>();

        try{
            BufferedReader fin = new BufferedReader(new InputStreamReader(openFileInput(asignaturas[0])));

            String nombre = fin.readLine();
            String dia = fin.readLine();
            while(!dia.equals("Nada")){
                String in = fin.readLine();
                String fn = fin.readLine();
                dia = fin.readLine();
                }
            prueba.setText(nombre);
            prueba2.setText(dia);
            }

            catch (Exception ex)
            {
                Log.e("Ficheros", "Error al leer fichero desde memoria interna");
            }

        }
          */
        Intent intent = new Intent(this, MostrarHorario.class);
        startActivity(intent);

    }

    public void borrarAsignatura(View view){
        Intent intent = new Intent(this, BorrarAsignatura.class);
        startActivity(intent);
    }

}
