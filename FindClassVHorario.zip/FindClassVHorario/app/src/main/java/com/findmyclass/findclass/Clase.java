package com.findmyclass.findclass;

public class Clase {

    String nom;
    String h_inicio, h_fin;

    public Clase(String s, String i, String f){
        nom = s;
        h_inicio = i;
        h_fin = f;
    }

    public String getNombre(){
        return nom;
    }


}
