package com.findmyclass.findclass;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MostrarHorario extends Activity {



    private LinearLayout linear1, linear2, linear3,linear4, linear5;


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mostrar_horario);

        linear1 = (LinearLayout)findViewById(R.id.linear1);
        linear2 = (LinearLayout)findViewById(R.id.linear2);
        linear3 = (LinearLayout) findViewById(R.id.linear3);
        linear4 = (LinearLayout) findViewById (R.id.linear4);
        linear5 = (LinearLayout) findViewById (R.id.linear5);


        String[] asignaturas = fileList();


        ArrayList<String> lunes = new ArrayList<String>();
        ArrayList<String> martes = new ArrayList<String>();
        ArrayList<String> miercoles = new ArrayList<String>();
        ArrayList<String> jueves = new ArrayList<String>();
        ArrayList<String> viernes = new ArrayList<String>();


        for(String s : asignaturas){
            try{
                BufferedReader fin = new BufferedReader(new InputStreamReader(openFileInput(s)));

                String nombre = fin.readLine();
                String dia = fin.readLine();
                while(!dia.equals("Nada")){
                    String in = fin.readLine();
                    String fn = fin.readLine();

                    if(dia.equals("Lunes")){
                        lunes.add(nombre);
                        lunes.add(in);
                        lunes.add(fn);
                    }
                    else if(dia.equals("Martes")){
                        martes.add(nombre);
                        martes.add(in);
                        martes.add(fn);
                    }
                    else if(dia.equals("Miercoles")){
                        miercoles.add(nombre);
                        miercoles.add(in);
                        miercoles.add(fn);
                    }
                    else if(dia.equals("Jueves")){
                        jueves.add(nombre);
                        jueves.add(in);
                        jueves.add(fn);
                    }
                    else if(dia.equals("Viernes")){
                        viernes.add(nombre);
                        viernes.add(in);
                        viernes.add(fn);
                    }
                    dia = fin.readLine();
                }

                fin.close();
            }
            catch (Exception ex)
            {
                Log.e("Ficheros", "Error al leer fichero desde memoria interna");
            }
        }


        for(int i = 0 ; i < lunes.size(); i = i + 3){
            TextView t_nombre = new TextView(this);
            TextView t_hora = new TextView(this);

            t_nombre.setText(lunes.get(i));

            String hora = lunes.get(i+1) + "  -  " + lunes.get(i+2);

            t_hora.setText(hora);

            t_nombre.setTextSize(25);
            t_nombre.setPadding(20,50,20,50);
            t_nombre.setGravity(Gravity.CENTER);

            t_hora.setGravity(Gravity.CENTER);
            t_hora.setPadding(20,20,20,40);

            ((LinearLayout)linear1).addView(t_nombre);
            ((LinearLayout)linear1).addView(t_hora);

        }

        for(int i = 0 ; i < martes.size(); i = i + 3){
            TextView t_nombre = new TextView(this);
            TextView t_hora = new TextView(this);

            t_nombre.setText(martes.get(i));

            String hora = martes.get(i+1) + "  -  " + martes.get(i+2);

            t_hora.setText(hora);

            t_nombre.setTextSize(25);
            t_nombre.setPadding(20,50,20,50);
            t_nombre.setGravity(Gravity.CENTER);

            t_hora.setGravity(Gravity.CENTER);
            t_hora.setPadding(20,20,20,40);

            ((LinearLayout)linear2).addView(t_nombre);
            ((LinearLayout)linear2).addView(t_hora);
        }

        for(int i = 0 ; i < miercoles.size(); i = i + 3){
            TextView t_nombre = new TextView(this);
            TextView t_hora = new TextView(this);

            t_nombre.setText(miercoles.get(i));

            String hora = miercoles.get(i+1) + "  -  " + miercoles.get(i+2);

            t_hora.setText(hora);

            t_nombre.setTextSize(25);
            t_nombre.setPadding(20,50,20,50);
            t_nombre.setGravity(Gravity.CENTER);

            t_hora.setGravity(Gravity.CENTER);
            t_hora.setPadding(20,20,20,40);

            ((LinearLayout)linear3).addView(t_nombre);
            ((LinearLayout)linear3).addView(t_hora);
        }

        for(int i = 0 ; i < jueves.size(); i = i + 3){
            TextView t_nombre = new TextView(this);
            TextView t_hora = new TextView(this);

            t_nombre.setText(jueves.get(i));

            String hora = jueves.get(i+1) + "  -  " + jueves.get(i+2);

            t_hora.setText(hora);

            t_nombre.setTextSize(25);
            t_nombre.setPadding(20,50,20,50);
            t_nombre.setGravity(Gravity.CENTER);

            t_hora.setGravity(Gravity.CENTER);
            t_hora.setPadding(20,20,20,40);

            ((LinearLayout)linear4).addView(t_nombre);
            ((LinearLayout)linear4).addView(t_hora);
        }

        for(int i = 0 ; i < viernes.size(); i = i + 3){
            TextView t_nombre = new TextView(this);
            TextView t_hora = new TextView(this);

            t_nombre.setText(viernes.get(i));

            String hora = viernes.get(i+1) + "  -  " + viernes.get(i+2);

            t_hora.setText(hora);

            t_nombre.setTextSize(25);
            t_nombre.setPadding(20,50,20,50);
            t_nombre.setGravity(Gravity.CENTER);

            t_hora.setGravity(Gravity.CENTER);
            t_hora.setPadding(20,20,20,40);

            ((LinearLayout)linear5).addView(t_nombre);
            ((LinearLayout)linear5).addView(t_hora);
        }
    }



}
