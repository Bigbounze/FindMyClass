package com.findmyclass.findclass;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class BusquedaClase extends Activity
{
    int[] idIncluidos = new int[10];
    int numeroAsignaturas;
    int id;

    Bundle datos;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.busqueda);

        datos = getIntent().getExtras();
        numeroAsignaturas = datos.getInt("numeroAsignaturas");
        idIncluidos = datos.getIntArray("idIncluidos");

                String datosObtenidos = "Asignatura: " + datos.getString("asignatura") + "\n"
                + "Dia: " + datos.getString("dia") + "\n"
                + "Horario: " + datos.getString("horario") + "\n"
                + "Direccion: " + datos.getString("direccion") + "\n"
                + "Planta: " + datos.getString("planta") + "\n"
                + "Edificio: " + datos.getString("edificio") + "\n"
                + "Facultad: " + datos.getString("facultad") + "\n"
                + "Aula: " + datos.getString("aula") + "\n"
                + "Pais: " + datos.getString("pais") + "\n"
                + "Ciudad: " + datos.getString("ciudad") + "\n"
                + "Prueba: " + numeroAsignaturas + "\n";
        TextView mostrarClase = findViewById(R.id.infoHorario);
        mostrarClase.setText(datosObtenidos);

        id = datos.getInt("id");

        if(numeroAsignaturas == 0)
        {
            Button boton = (Button) findViewById(R.id.aniadir);
            boton.setEnabled(true);

            Button botonQuitar = (Button) findViewById(R.id.quitar);
            botonQuitar.setEnabled(false);
        }
        else
        {
            boolean hayAsignatura = false;

            for(int i = 0; i < numeroAsignaturas; i++)
            {
                if(!hayAsignatura)
                {
                    if(idIncluidos[i] == id)
                    {
                        hayAsignatura = true;
                    }
                }
            }

            if(hayAsignatura){
                Button boton = (Button) findViewById(R.id.aniadir);
                boton.setEnabled(false);

                Button botonQuitar = (Button) findViewById(R.id.quitar);
                botonQuitar.setEnabled(true);
            }
            else {
                Button boton = (Button) findViewById(R.id.aniadir);
                boton.setEnabled(true);

                Button botonQuitar = (Button) findViewById(R.id.quitar);
                botonQuitar.setEnabled(false);
            }
        }

    }



    public void Aniadir(View vista)
    {
        idIncluidos[numeroAsignaturas] = id;
        numeroAsignaturas++;

        Button boton = (Button) findViewById(R.id.aniadir);
        boton.setEnabled(false);

        Button botonQuitar = (Button) findViewById(R.id.quitar);
        botonQuitar.setEnabled(true);
    }



    public void Quitar(View vista)
    {
        int posicion = -1;

        for(int i = 0; i < numeroAsignaturas; i++)
        {
            if(idIncluidos[i] == id)
            {
                posicion = i;
            }
        }

        if(posicion != numeroAsignaturas - 1)
        {
            for(int i = posicion; i < numeroAsignaturas - 1 ; i++)
            {
                idIncluidos[i] = idIncluidos[i+1];
            }

        }

        numeroAsignaturas--;

        Button boton = (Button) findViewById(R.id.aniadir);
        boton.setEnabled(true);

        Button botonQuitar = (Button) findViewById(R.id.quitar);
        botonQuitar.setEnabled(false);
    }



    public void onBackPressed()
    {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("numeroAsignaturas", numeroAsignaturas);
        i.putExtra("idIncluidos", idIncluidos);
        startActivity(i);
    }



    public void AbrirMapa(View vista)
    {
        Intent i = new Intent(this, MapaUniversidad.class);
        i.putExtra("longitudes", datos.getDouble("longitud"));
        i.putExtra("latitudes", datos.getDouble("latitud"));
        i.putExtra("nombreAsignatura", datos.getString("asignatura"));
        i.putExtra("nombreAula", datos.getString("aula"));


        startActivity(i);
    }
}
