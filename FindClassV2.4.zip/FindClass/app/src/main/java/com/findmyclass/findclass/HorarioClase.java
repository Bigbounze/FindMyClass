package com.findmyclass.findclass;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class HorarioClase extends Activity
{
    int[] idIncluidos = new int[10];
    int numeroAsignaturas = 0;

    TextView lunes, martes, miercoles, jueves, viernes;
    String textoLunes, textoMartes, textoMiercoles, textoJueves, textoViernes;


    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.horario);

        Bundle datos = getIntent().getExtras();

        numeroAsignaturas = datos.getInt("numeroAsignaturas");
        idIncluidos = datos.getIntArray("idIncluidos");

        lunes = findViewById(R.id.lunes);
        martes = findViewById(R.id.martes);
        miercoles = findViewById(R.id.miercoles);
        jueves = findViewById(R.id.jueves);
        viernes = findViewById(R.id.viernes);

        textoLunes = " Lunes: ";
        textoMartes = " Martes: ";
        textoMiercoles = " Miercoles: ";
        textoJueves = " Jueves: ";
        textoViernes = " Viernes: ";

        if(numeroAsignaturas != 0)
        {
            for(int i = 0; i < numeroAsignaturas; i++)
            {
                if(idIncluidos[i] == 1)
                {
                    textoLunes += "Prueba1 - Edificio 1 - Planta 0 - Aula 0.1 - Hora 8:50-10:50 \n";
                    textoMartes += "Prueba1 - Edificio 1 - Planta 0 - Aula 0.1 - Hora 10:50-11:50 \n";
                }
                else if(idIncluidos[i] == 144){
                    textoMiercoles += "Prueba2 - Edificio 3 - Planta 2 - Aula 0.1 - Hora 8:50-10:50 \n";
                }
                else if (idIncluidos[i] == 145){
                    textoJueves += "Prueba3 - Edificio 5 - Planta 4 - Aula 0.1 - Hora 8:50-10:50 \n";
                }
                else if (idIncluidos[i] == 146){
                    textoViernes += "Prueba3 - Edificio 7 - Planta 6 - Aula 0.1 - Hora 8:50-10:50 \n";
                }
                else if (idIncluidos[i] == 148){
                    textoMartes += "Principles Of Programming Languages - Edificio 21 - Planta 0 - Aula E.G.4 - Hora 13:15-15:15 \n";
                    textoViernes += "Principles Of Programming Languages - Edificio 21 - Planta 0 - Aula E.G.4 - Hora 13:15-15:15 \n";
                }
                else if (idIncluidos[i] == 149){

                    textoMiercoles += "Design And Implementation Of Mobile Applications - Edificio 25 - Planta 3 - Aula D.3.3 - Hora 8:15-10:15 \n";
                    textoJueves += "Design And Implementation Of Mobile Applications - Edificio 25 - Planta 3 - Aula D.3.3 - Hora 8:15-10:15 \n";
                }
                else if (idIncluidos[i] == 150){
                    textoMiercoles += "Robotics - Edificio 5 - Planta 0 - Aula 5.0.1 - Hora 16:15-18:15 \n";
                    textoLunes += "Robotics - Edificio 5 - Planta 0 - Aula 5.0.1 - Hora 14:15-16:15 \n";
                }
                else if (idIncluidos[i] == 151){
                    textoMartes += "Fisica - Edificio B8 - Planta 0 - Aula B8 0.6 - Hora 9:00-11:00 \n";
                    textoViernes += "Fisica - Edificio B8 - Planta 0 - Aula B8 0.6 - Hora 9:00-11:00 \n";
                }
            }

            lunes.setText(textoLunes);
            martes.setText(textoMartes);
            miercoles.setText(textoMiercoles);
            jueves.setText(textoJueves);
            viernes.setText(textoViernes);
        }
    }



    public void Volver(View vista)
    {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }
}
